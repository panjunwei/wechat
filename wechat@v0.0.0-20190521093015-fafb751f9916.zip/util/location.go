package util

import "time"

var BeijingLocation = time.FixedZone("Asia/Shanghai", 8*60*60)
