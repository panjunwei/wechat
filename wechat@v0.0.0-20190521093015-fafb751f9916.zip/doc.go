// https://github.com/chanxuehong/wechat
package wechat
