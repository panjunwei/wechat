// 模板消息接口.
package template
