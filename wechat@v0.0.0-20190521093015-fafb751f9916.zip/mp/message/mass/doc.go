// 群发消息.
package mass
