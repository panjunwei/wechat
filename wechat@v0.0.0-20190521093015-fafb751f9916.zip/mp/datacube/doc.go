// 数据统计接口.
package datacube
