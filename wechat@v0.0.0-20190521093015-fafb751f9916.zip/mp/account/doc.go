// 账号管理.
//
//  二维码管理在 qrcode 模块.
package account
