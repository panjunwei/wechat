// 自定义菜单接口.
package menu
