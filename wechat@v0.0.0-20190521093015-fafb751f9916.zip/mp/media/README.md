## 临时素材管理

* 永久素材管理在 material 模块
* 对于图文消息里的图片, 可以调用 base.UploadImage 或者 base.UploadImageFromReader 来上传