// 二维码接口.
package qrcode
