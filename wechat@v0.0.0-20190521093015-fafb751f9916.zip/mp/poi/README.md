## 微信门店接口.

* 对于门店的图片, 可以调用 base.UploadImage 或者 base.UploadImageFromReader 来上传.
