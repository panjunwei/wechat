## 提供 debug 和 release 两个版本的实现
