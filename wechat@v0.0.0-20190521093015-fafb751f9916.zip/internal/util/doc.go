// 提供一些实用函数
package util
